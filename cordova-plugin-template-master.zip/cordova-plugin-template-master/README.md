Cordova Plugin Template
======

This is a simple starting point for building a Cordova plugin on iOS and Android.
